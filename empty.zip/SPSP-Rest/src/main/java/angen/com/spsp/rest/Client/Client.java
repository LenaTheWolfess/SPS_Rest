/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest.Client;

import angen.com.spsp.rest.Product;
import angen.com.spsp.rest.ProductList;
import angen.com.spsp.rest.Review;
import angen.com.spsp.rest.ReviewList;
import java.util.ArrayList;
import java.util.List;
import org.restlet.resource.ClientResource;
/**
 *
 * @author Slavomír
 */
public class Client
{
				public static void main(String args[]) {
				}
}
