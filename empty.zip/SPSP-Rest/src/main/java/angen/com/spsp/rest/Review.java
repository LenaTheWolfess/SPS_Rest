/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

/**
 *
 * @author Slavomír
 */
public class Review
{
					private String author;
					private String text;

					public Review() {
										
					}

					public Review(String author, String text)
					{
										this.author = author;
										this.text = text;
					}
					
					public String getAuthor()
					{
										return author;
					}

					public void setAuthor(String author)
					{
										this.author = author;
					}

					public String getText()
					{
										return text;
					}

					public void setText(String text)
					{
										this.text = text;
					}
					public String toString()
					{
										return "author: " + author + ", text: " + text;
					}
}
