/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Slavomír
 */
public class Product
{
					private Long id;
					private String name;
					private float price;
					private List<Review> reviews = new ArrayList<>();
					
					public Product()
					{
										
					}

					public Product(String name, float price)
					{
										this.name = name;
										this.price = price;
					}
					
					public String getName()
					{
										return name;
					}

					public void setName(String name)
					{
										this.name = name;
					}

					public float getPrice()
					{
										return price;
					}

					public void setPrice(float price)
					{
										this.price = price;
					}
					
					public String toString(){
										return "name: " + name + ", price: " + price;
					}
					
					public void setId(Long id) {
										this.id = id;
					}
					
					public Long getId() {
										return id;
					}
					
					public List<Review> getReviews() {
										return reviews;
					}
					
					public void setReviews(List<Review> reviews)  {
										this.reviews = reviews;
					}
					
					public void update(Product product) {
										if (product == null)
															return;
										this.name = product.getName();
										this.price = product.getPrice();
										this.reviews = product.getReviews();
					}
}
