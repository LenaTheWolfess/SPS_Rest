/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest.Client;

import angen.com.spsp.rest.Product;
import angen.com.spsp.rest.ProductList;
import angen.com.spsp.rest.Review;
import angen.com.spsp.rest.ReviewList;
import java.util.ArrayList;
import java.util.List;
import org.restlet.resource.ClientResource;
/**
 *
 * @author Slavomír
 */
public class Client
{
				public static void main(String args[]) throws Exception{
									ClientResource clientResource = new ClientResource("http://localhost:8182/products");
									clientResource.post(new Product("product 1", 10));
									clientResource.post(new Product("product 2", 10));
									List<Product> products = clientResource.get(ProductList.class);
									ClientResource productResource = new ClientResource("http://localhost:8182/products/1");
									ClientResource reviewResource = new ClientResource("http://localhost:8182/products/1/reviews");
									reviewResource.post(new Review("slavko", "dobre"));
									System.out.println(products);
									Product product = productResource.get(Product.class);
									System.out.println(product);
									product.setName("updated");
									clientResource.put(product);
									product = productResource.get(Product.class);
									System.out.println(product);
									List<Review> reviews = reviewResource.get(ReviewList.class);
									System.out.println(reviews);
								 productResource.delete();
									System.out.println(products);
				}
}
