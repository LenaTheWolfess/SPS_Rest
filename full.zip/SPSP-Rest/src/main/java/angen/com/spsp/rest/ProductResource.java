/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

import java.util.List;
import org.restlet.data.Status;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

/**
 *
 * @author Slavomír
 */
public class ProductResource extends ServerResource
{
					private Long id;
					
					@Override
					public void doInit() throws ResourceException {
										String stringId = (String) getRequestAttributes().get("id");
										if (stringId == null) {
															this.id = 0L;
															return;
										}
										this.id = Long.parseLong(stringId);
					}
					
					@Get("json")
					public Product findById() {
										List<Product>  products = ProductsResource.products;
										for (Product product: products) {
															if (id.equals(product.getId()))
																				return product;
										}
										throw new ResourceException(Status.CLIENT_ERROR_NOT_FOUND);
					}
					
					@Delete
					public void remove() {
										Product product = findById();
										if (product == null)
															return;
										List<Product>  products = ProductsResource.products;
										products.remove(product);
					}
}
