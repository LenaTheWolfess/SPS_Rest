/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

import java.util.ArrayList;
import java.util.List;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;

/**
 *
 * @author Slavomír
 */
public class ProductsResource extends ServerResource
{
					public static List<Product> products = new ArrayList<>();
					private static Long lastId = 0L;
					@Get("json")
					public List<Product> getProducts() {
										return products;
					}
					@Post
					public void add(Product product) {
										lastId++;
										product.setId(lastId);
										products.add(product);
					}
					@Put
					public void update(Product product) {
										for(Product pr: products) {
															if (pr.getId().equals(product.getId())) {
																				pr.update(product);
																				break;
															}
										}
					}
					@Delete
					public void remove() {
									products.clear();
					}
}
