/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

import java.util.ArrayList;
import java.util.List;
import org.restlet.data.Status;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

/**
 *
 * @author Slavomír
 */
public class ReviewsResource extends ServerResource
{
					public static List<Review> reviews;
					private Long productId;
					@Override
					public void doInit() throws ResourceException {
										String stringId = (String) getRequestAttributes().get("id");
										if (stringId == null) {
															this.productId = 0L;
															return;
										}
										this.productId = Long.parseLong(stringId);
										List<Product> products = ProductsResource.products;
										for (Product product: products) {
															if (product.getId().equals(productId)) {
																				reviews = product.getReviews();
																				break;
															}
										}
					}
					
					@Get("json")
					public List<Review> getReviews() {
										if (reviews == null)
															throw new ResourceException(Status.CLIENT_ERROR_NOT_FOUND);
										return reviews;
					}
					@Post
					public void add(Review review) {
										getReviews().add(review);
					}
}
