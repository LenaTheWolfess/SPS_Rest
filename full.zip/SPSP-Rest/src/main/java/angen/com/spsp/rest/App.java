/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angen.com.spsp.rest;

import org.restlet.Component;
import org.restlet.data.Protocol;

/**
 *
 * @author Slavomír
 */
public class App
{
					public static void main(String args[]) throws Exception{
										Component component = new Component();
										component.getServers().add(Protocol.HTTP, 8182);
										component.getDefaultHost().attach("/products", ProductsResource.class);
										component.getDefaultHost().attach("/products/{id}", ProductResource.class);
										component.getDefaultHost().attach("/products/{id}/reviews", ReviewsResource.class);
										
										component.start();
					}
}
